
              <center><h1>Selamat Datang</h1><br><br>
              <img src="images/logouin.gif" />
              <p>Sistem Akademik merupakan sistem penilaian mahasiswa oleh dosen.</p>
              <p>Dosen dapat menginput nilai mahasiswa</p>
              <p>Mahasiswa dapat melihat nilai IP</p></center>
     <marquee direction="right" behavior="alternate">SELAMAT DATANG DI SISTEM AKADEMIK UIN SYARIFHIDAYATULLAH JAKARTA</marquee><br />
     <br />
            <br><br>
         
              
			
           